import React, { Component } from "react";
import { connect } from "react-redux";

import "./Style/index.less";
import NavCreate from "./Components/Nav";
import { Switch } from "react-router";

export interface NavEleme {
  name: string;
  state: boolean;
  callback: any;
  styleName: string;
  onPressFun(callback: string): void;
  icon?: string;
}

interface MyState {
  data?: NavEleme[];
  //   selectElementTableClien: {
  //     [key: string]: boolean;
  //   };
}

class TableOffice extends Component<any, MyState> {
  constructor(props) {
    super(props);
    // this.state = {
    //   selectElementTableClient:
    // };
  }

  getTableColumn(nameTab) {
    switch (nameTab) {
      case "client":
        return [
          {
            name: "",
            contentColumn: [""],
            personalClassName: "square",
            onPressFunc: console.log,
            callback: 3
          },
          // сформировать в конце и вставить в самое начало массива

          { name: "Id", contentColumn: ["1597"], personalClassName: "" },
          {
            name: "Логин",
            contentColumn: ["kimmimykim"],
            personalClassName: ""
          },
          {
            name: "Дата регист...",
            contentColumn: ["11.05.1996"],
            personalClassName: ""
          },
          {
            name: "Фамилия.",
            contentColumn: ["Blinov"],
            personalClassName: ""
          },
          { name: "Имя", contentColumn: ["Kim"], personalClassName: "" },
          { name: "Отчество", contentColumn: [""], personalClassName: "" },
          { name: "Тэг", contentColumn: ["Developer"], personalClassName: "" },
          { name: "Уровень", contentColumn: ["senior"], personalClassName: "" },
          { name: "Вес", contentColumn: ["106"], personalClassName: "" },
          {
            name: "E-mail",
            contentColumn: ["kimven.9@gmail.com"],
            personalClassName: ""
          },
          {
            name: "Телефон",
            contentColumn: ["+79199662587"],
            personalClassName: ""
          },
          { name: "Вкл...", contentColumn: ["вкл"], personalClassName: "" }
        ];

      default:
        return [
          {
            name: "",
            contentColumn: [""],
            personalClassName: "square",
            onPressFunc: console.log,
            callback: 3
          }
        ];
    }
  }

  getCurState(props) {
    const { match } = props;
    const data: NavEleme[] = [];
    // структура по которой рисую столбикик в таблице
    // рисую столбиками для ровных размеров в ширину и проще писать скрипт для изменения ширины

    const listView = this.getTableColumn(match.params.component);

    const initNav = [
      { name: "Клиенты", nameRoute: "client" },
      { name: "Группы", nameRoute: "group" },
      { name: "Букмекеры", nameRoute: "bookmakers" },
      { name: "Лево Василий1", nameRoute: "levo1", icon: "makeReport" },
      { name: "Маркетинг ст1", nameRoute: "marketing1", icon: "openBets" },
      { name: "Лево Василий2", nameRoute: "levo2", icon: "makeReport" },
      { name: "Маркетинг ст2", nameRoute: "marketing2", icon: "openBets" },
      { name: "Лево Василий3", nameRoute: "levo3", icon: "makeReport" },
      { name: "Маркетинг ст3", nameRoute: "marketing3", icon: "openBets" },
      { name: "Лево Василий4", nameRoute: "levo4", icon: "makeReport" },
      { name: "Маркетинг ст4", nameRoute: "marketing4", icon: "openBets" },
      { name: "Лево Василий5", nameRoute: "levo5", icon: "makeReport" },
      { name: "Маркетинг ст5", nameRoute: "marketing5", icon: "openBets" }
    ];

    initNav.forEach((element, index) => {
      if (element.nameRoute === match.params.component) {
      }
      data.push({
        name: element.name,
        state: element.nameRoute === match.params.component,
        callback: `/currentRates/${element.nameRoute}`,
        styleName: "",
        onPressFun: this.props.history.push,
        icon: element.icon
      });
    });

    return {
      data,
      listView
    };
  }

  getSubTitle(nameComponent) {
    switch (nameComponent) {
      case "marketing":
        return "Ставки группы “Маркетинг”";

      default:
        return "";
    }
  }

  render() {
    const { data, listView } = this.getCurState(this.props);

    const subTitle = this.getSubTitle(this.props.match.params.component);

    return (
      <div className="bookmaker_table">
        <NavCreate data={data} />
        <div className="bookmaker_table_container_table">
          {subTitle && (
            <div className="bookmaker_table_container_table_subTitle">
              {subTitle}
            </div>
          )}
          <div className="bookmaker_table_container_table_column">
            {listView.map((column: any, index) => {
              const {
                name,
                contentColumn,
                personalClassName,
                onPressFunc,
                callback
              } = column;
              return (
                <div
                  className="bookmaker_table_column_elements"
                  key={`column_${name + index}`}
                >
                  <div className="bookmaker_table_title_item">{name}</div>
                  {contentColumn.map((item, index) => {
                    return (
                      <div
                        key={`column_${name + index}_item_${index}`}
                        className={`bookmaker_table_content_item ${personalClassName}`}
                        onClick={
                          onPressFunc ? () => onPressFunc(callback) : f => f
                        }
                      >
                        {item}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(TableOffice);
